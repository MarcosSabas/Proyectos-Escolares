﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NCalc;


namespace Proyecto_Metodos_2_Parcial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //   Materia: Métodos Numericos
        //   Fecha 03/Noviembre/2024
        //   Sabas Perez Marcos Adahir
        //   Castillo García Jonathan Giovany
        //   Estefany Michelle Arana López

       //Método para calcular la función ingresada
       private double Funcion(string function, double x)
        {
            Expression e = new Expression(function);
            e.Parameters["x"] = x;
            return Convert.ToDouble(e.Evaluate());
        }
        private void button1_Click(object sender, EventArgs e)
        {
            // Leer los datos y convertirlos
            string function = textBox1.Text;
            double a = Convert.ToDouble(textBox2.Text);
            double b = Convert.ToDouble(textBox3.Text);

            try
            {
                // Operaciones
                double fxa = Funcion(function, a);
                double fxb = Funcion(function, b);
                double I = (b-a)*((fxa + fxb) / 2);
                label6.Text = $"I = {I}   u^2";

                tableLayoutPanel1.Controls.Clear();
                tableLayoutPanel1.RowCount = 1;
                tableLayoutPanel1.RowStyles.Clear();
                tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.AutoSize));

                // Agregar encabezados de la tabla
                tableLayoutPanel1.Controls.Add(new Label() { Text = "X" }, 0, 0);
                tableLayoutPanel1.Controls.Add(new Label() { Text = "f(X)" }, 1, 0);

                // Nuevos valores de X
                int row = 1;
                for (double x = -2; x <= b; x += 1)
                {
                    // Evaluar la función para el valor actual de X
                    double fx = Funcion(function, x);

                    // Añadir los valores a la tabla
                    tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                    tableLayoutPanel1.Controls.Add(new Label() { Text = x.ToString() }, 0, row);
                    tableLayoutPanel1.Controls.Add(new Label() { Text = fx.ToString() }, 1, row);

                    row++;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Leer los datos
            string function = textBox1.Text;
            double a = Convert.ToDouble(textBox2.Text);
            double b = Convert.ToDouble(textBox3.Text);
            double n = Convert.ToDouble(textBox4.Text);

            //operaciones
            double s = (b - a) / n;
            double suma = 0;
            double fxa = Funcion(function, a);
            double fxb = Funcion(function, b);

            try
            {
                tableLayoutPanel2.Controls.Clear();
                tableLayoutPanel2.RowCount = 1;
                tableLayoutPanel2.RowStyles.Clear();
                tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.AutoSize));

                // Agregar encabezados de la tabla
                tableLayoutPanel2.Controls.Add(new Label() { Text = "X" }, 0, 0);
                tableLayoutPanel2.Controls.Add(new Label() { Text = "f(X)" }, 1, 0);

                // Nuevos valores de X
                int row = 1;
                for (double x = a; x <= b; x += s)
                {
                    // Evaluar la función para el valor actual de X
                    double fx = Funcion(function, x);

                    // Añadir los valores a la tabla
                    tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                    tableLayoutPanel2.Controls.Add(new Label() { Text = x.ToString() }, 0, row);
                    tableLayoutPanel2.Controls.Add(new Label() { Text = fx.ToString() }, 1, row);

                    if (x > a && x < b)
                    {
                        suma += fx;
                        double res = (b - a) * ((fxa + 2 * (suma) + fxb) / (2 * (n)));
                        label9.Text = $"I = {res}   u^2";
                    }

                    row++;
                }

            }
            catch (Exception ex)
            {
                // Mostrar un mensaje en caso de error
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}
