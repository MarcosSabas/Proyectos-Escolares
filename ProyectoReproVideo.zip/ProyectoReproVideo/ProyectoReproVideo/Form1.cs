﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace ProyectoReproVideo
{
    public partial class Form1 : Form
    {
        String ruta = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog cargar = new OpenFileDialog();
            if (cargar.ShowDialog() == DialogResult.OK)
            {
                ruta = cargar.FileName;
                label1.Text = ruta;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            Thread hilo1 = new Thread(new ThreadStart(Reproducir));
            hilo1.Start();
            hilo1.Join();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void Reproducir()
        {
            CheckForIllegalCrossThreadCalls = false;
            Reproductor.URL = ruta;
            Reproductor.Ctlcontrols.play();
        }
        public void ActualizarD()
        {
            if (Reproductor.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                progressBar1.Maximum = (int)Reproductor.Ctlcontrols.currentItem.duration;
                timer1.Start();
            }
            else if (Reproductor.playState == WMPLib.WMPPlayState.wmppsPaused)
            {
                timer1.Stop();
            }
            else if (Reproductor.playState == WMPLib.WMPPlayState.wmppsStopped)
            {
                timer1.Stop();
                progressBar1.Value = 0;
            }
        }

        private void Reproductor_PlaylistChange(object sender, AxWMPLib._WMPOCXEvents_PlaylistChangeEvent e)
        {
            ActualizarD();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ActualizarD();
            progressBar1.Value = (int)Reproductor.Ctlcontrols.currentPosition;
            hora.Text = DateTime.Now.ToString("hh:mm");
            fecha.Text = DateTime.Now.ToShortDateString();
        }



        private void fecha_Click(object sender, EventArgs e)
        {

        }
    }
}
