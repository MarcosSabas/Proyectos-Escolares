img= zeros(250,250,3);
for l=0:10:250
    for k=0:10:250
        for i=1:1:5
            for j=1:1:5
      img(i+l,j+k,:)=255;
      img(i+l+5,j+k+5,:)=255;
            end
        end
    end
end
imshow(uint8(img));
imwrite(uint8(img),'cuadro.bmp','bmp');

