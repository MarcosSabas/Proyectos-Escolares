/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.Productos;
import modelo.Usuarios;
import modelo.Ventas;


/**
 *
 * @author francisco
 */
@WebServlet(urlPatterns = {"/Control"})
public class Control extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Control</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Control at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String opcion = request.getParameter("Opcion");
        if(opcion.equals("Registra")){
            Usuarios u=new Usuarios();
            u.setNombre(request.getParameter("nombreU"));
            u.setPaterno(request.getParameter("paternoU"));
            u.setMaterno(request.getParameter("maternoU"));
            u.setCorreo(request.getParameter("mail"));
            u.setTel(request.getParameter("telU"));
            
            String cod=request.getParameter("codigoU");
            cod=cod.toUpperCase();
            u.setCodigo(cod);
            if(cod.equals("CLIENTE")){
                u.guardarCliente();
            }
            else{u.guardarEmpleado();}
            
            String mensaje=u.getMensaje();
            if(u.getRespuesta().lastIndexOf("almacenado")>0)
            response.sendRedirect("Respuesta.jsp?respuesta="+mensaje);
            else
            response.sendRedirect("Error.jsp?respuesta="+u.getRespuesta());
        }
        
        if(opcion.equals("RegistraPro")){
            Usuarios u=new Usuarios();
            u.setNombre(request.getParameter("nombreP"));
            u.setMarca(request.getParameter("marcaP"));
            u.setTel(request.getParameter("telP"));
            u.guardarProveedor();
            String r=u.getMensaje();
            
            response.sendRedirect("Respuesta.jsp?respuesta="+r);
            
        }
        
        if(opcion.equals("IngresarEmp")){
            Usuarios u=new Usuarios();
            u.setUsuario(request.getParameter("usuario"));
            u.setPassword(request.getParameter("pass"));
            int puesto=u.buscarEmp(); 
            switch(puesto){
              case 1: response.sendRedirect("MenuAdministrador.html"); break;
              case 2: response.sendRedirect("MenuEmpleado.html"); break;
                        default:
                            response.sendRedirect("Error.jsp?respuesta= datos incorrectos");
            }
        }
        if(opcion.equals("IngresarCli")){
            Usuarios u=new Usuarios();
            u.setUsuario(request.getParameter("usuario"));
            u.setPassword(request.getParameter("pass"));
            u.buscarClie(); 
            
          response.sendRedirect("Ventas.html");
        }
        
        if(opcion.equals("RecuperaEmp")){
                Usuarios u = new Usuarios();
                u.setCorreo(request.getParameter("mail"));
                u.buscarEmp2();
                u.modificarContrasenaEmp();
                if(u.getRespuesta().lastIndexOf("modificado")>=0){
                    response.sendRedirect("Respuesta.jsp?respuesta="+u.getMensaje());
                    
                }else{
                  response.sendRedirect("Error.jsp?respuesta="+u.getMensaje());
                }
                
            }
        if(opcion.equals("Recupera")){
                Usuarios u = new Usuarios();
                u.setCorreo(request.getParameter("mail"));
                u.buscarClie2();
                u.modificarContrasenaClie();
                if(u.getRespuesta().lastIndexOf("modificado")>=0){
                    response.sendRedirect("Respuesta.jsp?respuesta="+u.getMensaje());
                    
                }else{
                  response.sendRedirect("Error.jsp?respuesta="+u.getMensaje());
                }
                
            }
        //Prodcutos
        if(opcion.equals("Guardar")){
            Productos p=new Productos();
            p.setNombre(request.getParameter("nombrep"));
            p.setPrecio(Float.parseFloat(request.getParameter("preciop")));
            p.setSotck(Integer.parseInt(request.getParameter("stockp")));
            p.setProveedor(Integer.parseInt(request.getParameter("proveedorp")));
            String r=p.alta();
            response.sendRedirect("Respuesta.jsp?respuesta="+r);
        }
        
        if(opcion.equals("Eliminar")){
           Productos p=new Productos();
            p.setId(Integer.parseInt(request.getParameter("nombrep")));
            String r=p.baja();
            response.sendRedirect("Respuesta.jsp?respuesta="+r);
        }
        Productos p=new Productos();
       if(opcion.equals("Consultar")){
             int nombre=Integer.parseInt(request.getParameter("nombrep"));
            p.setId(nombre);
            Productos w = p.buscar();
            String res = p.getRespuesta();
            if(res.lastIndexOf("encontrado")>=0){
                HttpSession sesion = request.getSession(true);
                sesion.setAttribute("id", w.getId());
                sesion.setAttribute("nombre", w.getNombre());
                sesion.setAttribute("precio", w.getPrecio());
                sesion.setAttribute("sotck", w.getSotck());
                response.sendRedirect("ConsultaProducto.jsp");
            }else{
                response.sendRedirect("Respuesta.jsp?respuesta="+res);
            }
        }
       
        if(opcion.equals("Buscar")){
            int nombre=Integer.parseInt(request.getParameter("nombrep"));
            p.setId(nombre);
            Productos w = p.buscar();
            String res = p.getRespuesta();
            if(res.lastIndexOf("encontrado")>=0){
                HttpSession sesion = request.getSession(true);
                sesion.setAttribute("id", w.getId());
                sesion.setAttribute("nombre", w.getNombre());
                sesion.setAttribute("precio", w.getPrecio());
                sesion.setAttribute("sotck", w.getSotck());
                response.sendRedirect("Ventas.jsp");
            }else{
                response.sendRedirect("Respuesta.jsp?respuesta="+res);
            }
        }    
        
        if(opcion.equals("Agregar")){
            Ventas v = new Ventas();
            v.setIdp(Integer.parseInt(request.getParameter("idp")));
            v.setCantidad(Integer.parseInt(request.getParameter("stockp")));
            Productos pro = new Productos();
            pro.setId(v.getIdp());
            pro = pro.buscar();
            v.setSubtotal(pro.getPrecio()*v.getCantidad());
            HttpSession sesion = request.getSession(true);
            Map <Integer,Ventas> mapa = new HashMap <Integer,Ventas>();
            mapa.put(1, v);
            sesion.setAttribute("mapa",mapa);
            response.sendRedirect("Ventas1.jsp");
        }
        
        if(opcion.equals("Buscar1")){
            int nombre = Integer.parseInt(request.getParameter("nombrep"));
            p.setId(nombre);
            Productos w = p.buscar();
            String res = p.getRespuesta();
            if(res.lastIndexOf("encontrado")>=0){
                HttpSession sesion = request.getSession(true);
                sesion.setAttribute("id", w.getId());
                sesion.setAttribute("nombre", w.getNombre());
                sesion.setAttribute("precio", w.getPrecio());
                sesion.setAttribute("sotck", w.getSotck());
                response.sendRedirect("Ventas2.jsp");
            }else{
                response.sendRedirect("Respuesta.jsp?respuesta="+res);
            }
        }    
           
        if(opcion.equals("Agregar1")){
            Ventas v = new Ventas();
            v.setIdp(Integer.parseInt(request.getParameter("idp")));
            v.setCantidad(Integer.parseInt(request.getParameter("stockp")));
            Productos pro = new Productos();
            pro.setId(v.getIdp());
            pro = pro.buscar();
            v.setSubtotal(pro.getPrecio()*v.getCantidad());
            HttpSession sesion = request.getSession(true);
            Map <Integer,Ventas> mapa = (HashMap <Integer,Ventas>)sesion.getAttribute("mapa");
            mapa.put(2, v);
            sesion.setAttribute("mapa",mapa);
            response.sendRedirect("Ventas3.jsp");
        }
        
        if(opcion.equals("Buscar2")){
            int nombre = Integer.parseInt(request.getParameter("nombrep"));
            p.setId(nombre);
            Productos w = p.buscar();
            String res = p.getRespuesta();
            if(res.lastIndexOf("encontrado")>=0){
                HttpSession sesion = request.getSession(true);
                sesion.setAttribute("id", w.getId());
                sesion.setAttribute("nombre", w.getNombre());
                sesion.setAttribute("precio", w.getPrecio());
                sesion.setAttribute("sotck", w.getSotck());
                response.sendRedirect("Ventas4.jsp");
            }else{
                response.sendRedirect("Respuesta.jsp?respuesta="+res);
            }
        }
        
        if(opcion.equals("Agregar2")){
            Ventas v = new Ventas();
            v.setIdp(Integer.parseInt(request.getParameter("idp")));
            v.setCantidad(Integer.parseInt(request.getParameter("stockp")));
            Productos pro = new Productos();
            pro.setId(v.getIdp());
            pro = pro.buscar();
            v.setSubtotal(pro.getPrecio()*v.getCantidad());
            HttpSession sesion = request.getSession(true);
            Map <Integer,Ventas> mapa = (HashMap<Integer,Ventas>)sesion.getAttribute("mapa");
            mapa.put(3, v);
            sesion.setAttribute("mapa",mapa);
            response.sendRedirect("Ventas5.jsp");
        }
        
        if(opcion.equals("Buscar3")){
            int nombre = Integer.parseInt(request.getParameter("nombrep"));
            p.setId(nombre);
            Productos w = p.buscar();
            String res = p.getRespuesta();
            if(res.lastIndexOf("encontrado")>=0){
                HttpSession sesion = request.getSession(true);
                sesion.setAttribute("id", w.getId());
                sesion.setAttribute("nombre", w.getNombre());
                sesion.setAttribute("precio", w.getPrecio());
                sesion.setAttribute("sotck", w.getSotck());
                response.sendRedirect("Ventas6.jsp");
            }else{
                response.sendRedirect("Respuesta.jsp?respuesta="+res);
            }
        }
        
        if(opcion.equals("Agregar3")){
            Ventas v = new Ventas();
            v.setIdp(Integer.parseInt(request.getParameter("idp")));
            v.setCantidad(Integer.parseInt(request.getParameter("stockp")));
            Productos pro = new Productos();
            pro.setId(v.getIdp());
            pro = pro.buscar();
            v.setSubtotal(pro.getPrecio()*v.getCantidad());
            HttpSession sesion = request.getSession(true);
            Map <Integer,Ventas> mapa = (HashMap<Integer,Ventas>)sesion.getAttribute("mapa");
            mapa.put(4, v);
            sesion.setAttribute("mapa",mapa);
            response.sendRedirect("Ventas7.jsp");
        }
        
        if(opcion.equals("Buscar4")){
            int nombre = Integer.parseInt(request.getParameter("nombrep"));
            p.setId(nombre);
            Productos w = p.buscar();
            String res = p.getRespuesta();
            if(res.lastIndexOf("encontrado")>=0){
                HttpSession sesion = request.getSession(true);
                sesion.setAttribute("id", w.getId());
                sesion.setAttribute("nombre", w.getNombre());
                sesion.setAttribute("precio", w.getPrecio());
                sesion.setAttribute("sotck", w.getSotck());
                response.sendRedirect("Ventas8.jsp");
            }else{
                response.sendRedirect("Respuesta.jsp?respuesta="+res);
            }
        }
        
        if(opcion.equals("Agregar4")){
            Ventas v = new Ventas();
            v.setIdp(Integer.parseInt(request.getParameter("idp")));
            v.setCantidad(Integer.parseInt(request.getParameter("stockp")));
            Productos pro = new Productos();
            pro.setId(v.getIdp());
            pro = pro.buscar();
            v.setSubtotal(pro.getPrecio()*v.getCantidad());
            HttpSession sesion = request.getSession(true);
            Map <Integer,Ventas> mapa = (HashMap<Integer,Ventas>)sesion.getAttribute("mapa");
            mapa.put(5, v);
            sesion.setAttribute("mapa",mapa);
            response.sendRedirect("Ventas9.jsp");
        }
        
        if(opcion.equals("Comprar")){
         HttpSession sesion = request.getSession(true);
         HashMap <Integer,Ventas> mapa = (HashMap)sesion.getAttribute("mapa");
         int i=0;
         Ventas ar[]=new Ventas[5];
         String res="";
         for (Map.Entry<Integer,Ventas>entry: mapa.entrySet()){
              ar[i]= new Ventas();
              ar[i]= entry.getValue();
              i++;
         }
         Ventas v = new Ventas();
         v.buscar();
         int idventa= v.getFolio();
         if(idventa==0)idventa=1;
         for(int j=0; j<ar.length;j++){
             v.setFolio(idventa);
             v.setIdp(ar[j].getIdp());
             v.setCantidad(ar[j].getCantidad());
             v.setSubtotal(ar[j].getSubtotal());
             v.agregar();
         }
         res=v.getRespuesta();
         response.sendRedirect("Respuesta.jsp?respuesta="+res);
        }
            
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
