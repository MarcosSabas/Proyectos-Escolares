/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.*;
/**
 *
 * @author francisco
 */
public class Productos {
    private String nombre,respuesta;
    private int sotck,id,proveedor;
    private float precio;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public int getProveedor() {
        return proveedor;
    }

    public void setProveedor(int proveedor) {
        this.proveedor = proveedor;
    }

   
    public int getSotck() {
        return sotck;
    }

    public void setSotck(int sotck) {
        this.sotck = sotck;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }
    public String alta(){
        try{
            Connection c=Conexion.conectar();
            //PreparedStatement at= c.prepareStatement("insert into producto(nombre,precio,stock,proveedor) values(?,?,?,?,?)");
            CallableStatement at=c.prepareCall("{Call dbo.altaproducto(?,?,?,?,?)}");
            at.setString(1,nombre);
            at.setFloat(2,precio);
            at.setInt(3,sotck);
            at.setInt(4,proveedor);
            at.registerOutParameter(5,Types.VARCHAR);
            at.execute();
            respuesta=at.getString(5);
            respuesta="El producto se ha dado de alta";
        }catch(Exception e){
            respuesta="Error en la alta del producto"+e;
        }
        return respuesta;
    }
    public Productos buscar(){
         Productos res=new Productos();
        try{
            Connection c=Conexion.conectar();
            if(c!=null){
            PreparedStatement ps=c.prepareStatement("select * from producto where id=?");
            ps.setInt(1, id);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                res.id=rs.getInt(1);
                res.nombre=rs.getString(2);
                res.precio=rs.getFloat(3);
                res.sotck=rs.getInt(4);
                res.proveedor=rs.getInt(5);
                respuesta="Dato encontrado";
            }
            else{
                res=null;
                respuesta="No encontro dato";
            }
            }
            else{
                respuesta="No hay conexion a la base";
            }
        }catch(Exception e){
            respuesta="Error en consultor"+e;
        }
        return res;
    }
    
         public String baja(){
             try{
            Connection c=Conexion.conectar();
            if(c!=null){
                     PreparedStatement pb=c.prepareStatement("delete from producto where id=?");
                     pb.setInt(1, id);
                     pb.execute();
                     respuesta="Producto eliminado";
                 }else{
                     respuesta="No se pudo conectar a la base de datos";
                 }
             }catch(Exception e){
            respuesta="Error en la alta del producto"+e;
        }
         return respuesta;
         }
}
