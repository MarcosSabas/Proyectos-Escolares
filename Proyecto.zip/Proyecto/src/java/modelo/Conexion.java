/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.*;
/**
 *
 * @author yaani
 */
public class Conexion {
    public static Connection conectar(){
        try{
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        Connection cn=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=SistemaVentas;user=sa;password=sasa;");
        return cn;
        }catch(Exception er){return null;}
    }
}
