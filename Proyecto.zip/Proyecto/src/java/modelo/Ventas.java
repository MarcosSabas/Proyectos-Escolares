/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.CallableStatement;
import java.sql.*;
import java.sql.Types;
/**
 *
 * @author francisco
 */
public class Ventas {
    private int folio,idp,cantidad,cliente;
    private float subtotal;
    private String fechar,respuesta;
    private int opcion;

    public int getFolio() {
        return folio;
    }

    public void setFolio(int folio) {
        this.folio = folio;
    }

    public int getIdp() {
        return idp;
    }

    public void setIdp(int idp) {
        this.idp = idp;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }

    public String getFechar() {
        return fechar;
    }

    public void setFechar(String fechar) {
        this.fechar = fechar;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public int getOpcion() {
        return opcion;
    }

    public void setOpcion(int opcion) {
        this.opcion = opcion;
        
    }
    
    public void agregar(){
        try {
            Connection c= Conexion.conectar();
            if (c!=null) {
                CallableStatement cs=c.prepareCall("{Call dbo.agregarventa(?,?,?,?)}");
                //cs.setInt(1, folio);
                cs.setInt(1, idp);
                cs.setInt(2, cantidad);
                cs.setFloat(3, subtotal);
                cs.registerOutParameter(4,Types.VARCHAR);
                cs.execute();
                respuesta=cs.getString(4);
            } else {
                respuesta="No hay conexion con la base de datos";
            }
        } catch (Exception e) {
            respuesta="Error en guardar venta"+e;
        }
    }
    
    public void buscar(){
        try {
            Connection c=Conexion.conectar();
            if (c!=null) {
                PreparedStatement ps=c.prepareStatement("select ((max(folio=))+1) from nota");
                ResultSet rs=ps.executeQuery();
                if (rs.next()) {
                    folio=rs.getInt(1);
                } else {
                    folio=1;
                }
            } else {
                respuesta="No hay conexion con la base de datos";
            }
        } catch (Exception e) {
            respuesta="Error al buscar folio"+e;
        }
    }
}
