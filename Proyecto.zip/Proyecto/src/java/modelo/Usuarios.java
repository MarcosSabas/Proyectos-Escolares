/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author francisco
 */
public class Usuarios {
    private String nombre,paterno,materno,tel,usuario,correo,password,marca,codigo;
    private String respuesta,mensaje;
    private int opcion,puesto;
    String letras="ABCDEFGHIJKLMNÑOPQRSTUWXYZ";
    
    public String generaUsuario(){
    String temporal= nombre.substring(0,3)+paterno.substring(0,3)+materno.substring(0,3);
    int aleatorio=(int)(Math.random()*1000);
    if(aleatorio<10) temporal+="00"+aleatorio;
    else if(aleatorio<100) temporal+="0"+aleatorio;
    else temporal += aleatorio;
    return temporal;
    }
    public String codificar(String texto){
        texto=texto.toUpperCase();
    String textocodificado="";
    for(int i = 0; i < texto.length(); i++){
        char caracter=texto.charAt(i);
     int pos=letras.indexOf(caracter);
     if(pos==-1){
         textocodificado+=caracter;
     }
     else{
         textocodificado+=letras.charAt((pos+3)%letras.length());
     }
    }
         return textocodificado;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPaterno() {
        return paterno;
    }

    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    public String getMaterno() {
        return materno;
    }

    public void setMaterno(String materno) {
        this.materno = materno;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public int getPuesto() {
        return puesto;
    }

    public void setPuesto(int puesto) {
        this.puesto = puesto;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public int getOpcion() {
        return opcion;
    }

    public void setOpcion(int opcion) {
        this.opcion = opcion;
    }
    public void guardarProveedor(){
        try{
            Connection c=Conexion.conectar();
            PreparedStatement pp=c.prepareStatement("insert into proveedor(nombre,marca,telefono) values (?,?,?)");
            pp.setString(1, nombre);
            pp.setString(2, marca);
            pp.setString(3, tel);
            pp.execute();
            mensaje="Proveedor almacenado";
            
        }catch(Exception e){
            respuesta="error en guardar proveedor"+e;
        }
    }
    public void guardarEmpleado(){
        if(codigo.equals("ADMINISTRADOR")){
            try{
            Connection c=Conexion.conectar();
            PreparedStatement pa=c.prepareStatement("insert into empleados(nombre,apaterno,amaterno,telefono,puesto,usuario,correo,password) values (?,?,?,?,?,?,?,?)");
            pa.setString(1, nombre);
            pa.setString(2, paterno);
            pa.setString(3, materno);
            pa.setString(4, tel);
            pa.setInt(5, 1);
            usuario=generaUsuario();
            pa.setString(6, usuario);
            pa.setString(7, correo);
            pa.setString(8,EncriptarMD5.encriptaEnMD5(codificar(usuario)));
            pa.execute();
            mensaje= "Hola fuiste dado de alta como ADMINISTRADOR, tu nombre es "+nombre+" "+paterno+"\n"+"Bienvenido a GrantelStore \n"+"Tu usuario es "+usuario+" y tu contraseña "+codificar(usuario);
            respuesta="usuario almacenado";
        }catch(Exception e){
            respuesta="error en guardar usuario"+e;
        }
        }
        if(codigo.equals("EMPLEADO")){
            try{
            Connection c=Conexion.conectar();
            PreparedStatement pe=c.prepareStatement("insert into empleados(nombre,apaterno,amaterno,telefono,puesto,usuario,correo,password) values (?,?,?,?,?,?,?,?)");
            pe.setString(1, nombre);
            pe.setString(2, paterno);
            pe.setString(3, materno);
            pe.setString(4, tel);
            pe.setInt(5, 2);
            usuario=generaUsuario();
            pe.setString(6, usuario);
            pe.setString(7, correo);
            pe.setString(8,EncriptarMD5.encriptaEnMD5(codificar(usuario)));
            pe.execute();
            
            mensaje= "Hola fuiste dado de alta como EMPLEADO,tu nombre es "+nombre+" "+paterno+"\n"+"Bienvenido a GrantelStore \n"+"Tu usuario es "+usuario+" y tu contraseña "+codificar(usuario);
            respuesta="usuario almacenado";
        }catch(Exception e){
            respuesta="error en guardar usuario"+e;
        }
        }
    }
    
    public void guardarCliente(){
        try{
            Connection c=Conexion.conectar();
            PreparedStatement ps=c.prepareStatement("insert into cliente(nombre,apaterno,amaterno,telefono,usuario,correo,password) values (?,?,?,?,?,?,?)");
            ps.setString(1, nombre);
            ps.setString(2, paterno);
            ps.setString(3, materno);
            ps.setString(4, tel);
            
            usuario=generaUsuario();
            ps.setString(5, usuario);
            ps.setString(6, correo);
            ps.setString(7,EncriptarMD5.encriptaEnMD5(codificar(usuario)));
            ps.execute();
            
            mensaje= "Hola fuiste registrado con exito, su nombre es "+nombre+" "+paterno+"\n"+"Bienvenido a GrantelStore \n"+"Tu usuario es "+usuario+" y tu contraseña "+codificar(usuario);
            respuesta="usuario almacenado";
            
            
        }catch(Exception e){
            respuesta="error en guardar usuario"+e;
        }
    }
    
    public int buscarEmp(){
        try{
        Connection c= Conexion.conectar();
        PreparedStatement ps=c.prepareStatement("select puesto from empleados where usuario=? and password=?");
        ps.setString(1,usuario);
         ps.setString(2,EncriptarMD5.encriptaEnMD5(password));
        ResultSet rs =ps.executeQuery();
        if(rs.next()){
            return rs.getInt(1);
        }else{
            return -1;
        }
    }catch(Exception er){
        respuesta = "Error en buscar al empleado"+er;
        return -1;
    }
 }
    
      public int buscarClie(){
        try{
        Connection c= Conexion.conectar();
        PreparedStatement ps=c.prepareStatement("select * from cliente where usuario=? and password=?");
        ps.setString(1,usuario);
        ps.setString(2,EncriptarMD5.encriptaEnMD5(password));
        ResultSet rs =ps.executeQuery();
        if(rs.next()){
            return rs.getInt(1);
        }else{
            return -1;
        }
    }catch(Exception er){
        respuesta = "Error en buscar al cliente"+er;
        return -1;
    }
 }
      
         public void buscarEmp2(){
        try{
        Connection c= Conexion.conectar();
        PreparedStatement ps=c.prepareStatement("select nombre,apaterno,amaterno from empleados where correo=?");
        ps.setString(1,correo);
        ResultSet rs =ps.executeQuery();
        if(rs.next()){
            nombre= rs.getString(1);
            paterno= rs.getString(2);
            materno= rs.getString(3);
            respuesta="Dato encontrado";

        }else{
            respuesta="No existes";
        }
    }catch(Exception er){
        respuesta = "Error en buscar datos del Empleado"+er;
       
    }
 }
         public void modificarContrasenaEmp(){
    try{
        Connection c= Conexion.conectar();
        String cad  ="update empleados set usuario=?,password=? where correo=?";
        PreparedStatement ps= c.prepareStatement(cad);
        usuario=generaUsuario();
        ps.setString(2,EncriptarMD5.encriptaEnMD5(codificar(usuario)));
        ps.setString(1,usuario);
        ps.setString(3,correo);
        ps.execute();     
        mensaje= "Hola "+nombre+" "+paterno+" "+materno+" te informamos por este medio que tu usuario y contraseña han cambiado, tu nuevo usuario es  "+usuario+" y su password es "+codificar(usuario)+" guarda tus datos actualizados";
        respuesta="Usuario modificado";
    }catch(Exception e){
        respuesta="Error en modificar la contraseña"+e;
      }
    }
         
       public void buscarClie2(){
        try{
        Connection c= Conexion.conectar();
        PreparedStatement ps=c.prepareStatement("select nombre,apaterno,amaterno from cliente where correo=?");
        ps.setString(1,correo);
        ResultSet rs =ps.executeQuery();
        if(rs.next()){
            nombre= rs.getString(1);
            paterno= rs.getString(2);
            materno= rs.getString(3);
            respuesta="Dato encontrado";

        }else{
            respuesta="No existes";
        }
    }catch(Exception er){
        respuesta = "Error en buscar datos del Empleado"+er;
       
    }
 }
    public void modificarContrasenaClie(){
    try{
        Connection c= Conexion.conectar();
        String cad  ="update cliente set usuario=?,password=? where correo=?";
        PreparedStatement ps= c.prepareStatement(cad);
        usuario=generaUsuario();
        ps.setString(2,EncriptarMD5.encriptaEnMD5(codificar(usuario)));
        ps.setString(1,usuario);
        ps.setString(3,correo);
        ps.execute();     
        mensaje= "Hola "+nombre+" "+paterno+" "+materno+" te informamos por este medio que tu usuario y contraseña han cambiado, tu usuario es  "+usuario+" y su password es "+codificar(usuario)+" guarda tus datos actualizados";
        respuesta="usuario modificado";
    }catch(Exception e){
        respuesta="error en modificar la contraseña"+e;
      }
    }
}
