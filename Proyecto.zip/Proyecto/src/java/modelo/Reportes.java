/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author francisco
 */
public class Reportes {
    private String respuesta;
    private int  opcion;

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public int getOpcion() {
        return opcion;
    }

    public void setOpcion(int opcion) {
        this.opcion = opcion;
        if(opcion==1){
            crearPDF1();
        }
        if(opcion==2){
            crearPDF2();
        }
    }
    
    public void crearPDF1(){
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream("C://Users//francisco//Documents//NetBeansProjects//Proyecto//Reportes//ReporteProductos.pdf"));
            document.open();
            Paragraph parrafo = new Paragraph();
            parrafo.setAlignment(Paragraph.ALIGN_CENTER);
            parrafo.setFont(FontFactory.getFont("Arial",30,Font.BOLD, BaseColor.RED));
            parrafo.add("REPORTE DE PRODUCTOS");
            document.add(parrafo);
            parrafo = new Paragraph();
            parrafo.add("\n\n");
            document.add(parrafo);
            PdfPTable table = new PdfPTable(5);
            table.addCell("id");
            table.addCell("nombre");
            table.addCell("precio");
            table.addCell("stock");
            table.addCell("proveedor");
            try {
                Connection c= Conexion.conectar();
                    if (c!=null) {
                        PreparedStatement ps=c.prepareStatement("select * from producto");
                        ResultSet rs = ps.executeQuery();
                        while(rs.next()){
                            table.addCell(rs.getString(1));
                            table.addCell(rs.getString(2));
                            table.addCell(rs.getString(3));
                            table.addCell(rs.getString(4));
                            table.addCell(rs.getString(5));
                        }
                    } else { respuesta = "No hay conexion a la base";
                    }
            } catch (Exception e) { respuesta ="Error al consultar la tabla"+e;
            }
                document.add(table);
                JFreeChart grafico;
                int largo=600; 
                int ancho=400;
                DefaultPieDataset datos2 = new DefaultPieDataset();
                try{
                    Connection c=Conexion.conectar();
                    if(c!=null){
                        PreparedStatement ps=c.prepareStatement("SELECT proveedor, SUM(stock) AS total_stock FROM producto GROUP BY proveedor ORDER BY proveedor;");
                        ResultSet rs=ps.executeQuery();
                        while(rs.next()){
                            datos2.setValue( rs.getString(1),rs.getInt(2));
                            grafico = ChartFactory.createPieChart3D("Productos con el mismo proveedor",datos2,false,true,true);
                            ChartUtilities.saveChartAsJPEG(new File("C://Users//francisco//Documents//NetBeansProjects//Proyecto//Reportes/graficoPie.jpg"), grafico, largo, ancho);
                        }
                    }
                    else{respuesta="No hay conexion a la base";}
                }catch(Exception e){
                    respuesta="Error en consultar tabla"+e;
                }
            Image imagen = Image.getInstance("C://Users//francisco//Documents//NetBeansProjects//Proyecto//Reportes//graficoPie.jpg");
            imagen.setAlignment(Image.ALIGN_CENTER);
            imagen.scalePercent(100);
            document.add(imagen);
            document.close();
                respuesta="Reporte creado";
        } catch (Exception e) { respuesta="Error "+e;
        }
    }
    
    public void crearPDF2(){
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream("C://Users//francisco//Documents//NetBeansProjects//Proyecto//Reportes//ReporteVentas.pdf"));
            document.open();
            Paragraph parrafo = new Paragraph();
            parrafo.setAlignment(Paragraph.ALIGN_CENTER);
            parrafo.setFont(FontFactory.getFont("Arial",30,Font.BOLD, BaseColor.BLUE));
            parrafo.add("REPORTE DE VENTAS");
            document.add(parrafo);
            parrafo = new Paragraph();
            parrafo.setAlignment(Paragraph.ALIGN_CENTER);
            parrafo.setFont(FontFactory.getFont("Arial",20,Font.BOLD, BaseColor.BLACK));
            parrafo.add("\n\nEstas son las ventas que se han realizado\n\n");
            document.add(parrafo);
            PdfPTable table = new PdfPTable(5);
            table.addCell("folio");
            table.addCell("clave_prod");
            table.addCell("cantidad");
            table.addCell("subtotal");
            table.addCell("fecha");
            try {
                Connection c= Conexion.conectar();
                    if (c!=null) {
                        PreparedStatement ps=c.prepareStatement("select * from nota");
                        ResultSet rs = ps.executeQuery();
                        while(rs.next()){
                            table.addCell(rs.getString(1));
                            table.addCell(rs.getString(2));
                            table.addCell(rs.getString(3));
                            table.addCell(rs.getString(4));
                            table.addCell(rs.getString(5));
                        }
                    } else { respuesta = "No hay conexion a la base";
                    }
            } catch (Exception e) { respuesta ="Error al consultar la tabla"+e;
            }
                document.add(table);
            JFreeChart grafico;
            int largo=600; 
            int ancho=400;
            DefaultCategoryDataset datos= new DefaultCategoryDataset();
            try{
                    Connection c=Conexion.conectar();
                    if(c!=null){
                        PreparedStatement ps=c.prepareStatement("SELECT clave_prod, SUM(cantidad) AS total_vendido FROM nota GROUP BY clave_prod ORDER BY clave_prod;");
                        ResultSet rs=ps.executeQuery();
                        while(rs.next()){
                            datos.addValue(rs.getInt(2),rs.getString(1),"");
                            grafico = ChartFactory.createBarChart3D("Promedio de productos vendidos","Productos","total_vendido", datos,PlotOrientation.VERTICAL, true, true, true);
                            ChartUtilities.saveChartAsJPEG(new File("C://Users//francisco//Documents//NetBeansProjects//Proyecto//Reportes/graficoBarras.jpg"), grafico, largo, ancho);
                        }
                    }
                    else{respuesta="No hay conexion a la base";}
                }catch(Exception e){
                    respuesta="Error en consultar tabla"+e;
                }
            
            Image imagen = Image.getInstance("C://Users//francisco//Documents//NetBeansProjects//Proyecto//Reportes//graficoBarras.jpg");
            imagen.setAlignment(Image.ALIGN_CENTER);
            imagen.scalePercent(100);
            document.add(imagen);
                document.close();
                respuesta="Reporte creado";
        } catch (Exception e) { respuesta="Error "+e;
        }
    }
}
