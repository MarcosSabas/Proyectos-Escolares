﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica8
{
    public partial class Form1 : Form
    {
        enum posicion { der, izq, arr, abaj }
        private int x;
        private int y;
        private posicion objposicion;
        private List<Point> snake;  // Lista para los segmentos del snake
        private Point specialPoint;  // Punto especial en (100, 100)
        public Form1()
        {
            InitializeComponent();
            x = 0;
            y = 0;
            objposicion = posicion.der;
            snake = new List<Point>();
            snake.Add(new Point(x, y));  // Añadir la cabeza del snake a la lista
            specialPoint = new Point(100, 100);  // Inicializar el punto especial
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right)
            {
                objposicion = posicion.der;
            }
            else if (e.KeyCode == Keys.Left)
            {
                objposicion = posicion.izq;
            }
            else if (e.KeyCode == Keys.Up)
            {
                objposicion = posicion.arr;
            }
            else if (e.KeyCode == Keys.Down)
            {
                objposicion = posicion.abaj;
            }
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Dibujar el snake
            foreach (var segment in snake)
            {
                e.Graphics.FillRectangle(Brushes.Red, segment.X, segment.Y, 50, 50);
            }

            // Dibujar el cuadro en (100, 100)
            e.Graphics.FillRectangle(Brushes.Blue, specialPoint.X, specialPoint.Y, 50, 50);
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Mueve los segmentos del snake
            for (int i = snake.Count - 1; i > 0; i--)
            {
                snake[i] = snake[i - 1];
            }

            // Actualiza la posición de la cabeza
            if (objposicion == posicion.der)
            {
                x += 50;
            }
            else if (objposicion == posicion.izq)
            {
                x -= 50;
            }
            else if (objposicion == posicion.arr)
            {
                y -= 50;
            }
            else if (objposicion == posicion.abaj)
            {
                y += 50;
            }

            // Asegurarse de que el snake sigue dentro de los límites del formulario
            if (x >= Width) x = 0;
            if (x < 0) x = Width - 50;
            if (y >= Height) y = 0;
            if (y < 0) y = Height - 50;

            // Actualiza la cabeza del snake
            snake[0] = new Point(x, y);

            // Añadir segmentos al pasar por (100, 100)
            Rectangle snakeHead = new Rectangle(x, y, 50, 50);
            Rectangle specialArea = new Rectangle(specialPoint.X, specialPoint.Y, 50, 50);

            if (snakeHead.IntersectsWith(specialArea))
            {
                for (int i = 0; i < 3; i++)
                {
                    snake.Add(new Point(snake[snake.Count - 1].X, snake[snake.Count - 1].Y));
                }
            }

            Invalidate();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
