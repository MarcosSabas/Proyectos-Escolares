img01=imread('01.jpg');
img02=imread('02.jpg');
[x1 y1 z1] = size(img01);
[x2 y2 z2] = size(img02);
if x1 < x2
    x = x2;
else
    x = x2;
end

if y1 < y2
    y = y1;
else
    y = y2;
end
transp = zeros(x,y,3);
alp = 0.4;
for i =1: 1:x
    for j=1:1:y
        transp(i,j,:)=round(alp*img01(i,j,:)+(1-alp)*img02(i,j,:));
    end
end
subplot(1,3,1);
imshow(uint8(img01));
subplot(1,3,2);
imshow(uint8(img02));
subplot(1,3,3);
imshow(uint8(transp));
imwrite(uint8(transp),'casa.bmp','bmp');