% Leer la imagen desde un archivo
img = imread('foto.JPG');

% Obtener dimensiones de la imagen: ancho (x), alto (y) y n�mero de canales (z)
[x, y, z] = size(img);

% Generar una matriz de ruido gaussiano con media 0 y desviaci�n est�ndar 15
a = random('normal', 0, 15, x, y, z);

% Convertir la imagen original a tipo double para realizar c�lculos
img1 = double(img);

% Agregar el ruido a la imagen y redondear los valores
img1 = round(img1 + a);

% Crear matrices vac�as para las im�genes procesadas
img2 = zeros(x-2, y-2, 3); % Filtro de m�ximo
img3 = zeros(x-2, y-2, 3); % Filtro de m�nimo

% Aplicar filtros para cada canal por separado
for canal = 1:3
    for i = 2:x-1
        for j = 2:y-1
            % Filtro de m�ximo por canal
            vecindad_max = img1(i-1:i+1, j-1:j+1, canal);
            img2(i-1, j-1, canal) = max(vecindad_max(:));
            
            % Filtro de m�nimo por canal
            vecindad_min = img1(i-1:i+1, j-1:j+1, canal);
            img3(i-1, j-1, canal) = min(vecindad_min(:));
        end
    end
end

% Mostrar las cuatro im�genes en una �nica figura con subgr�ficos
figure;
subplot(2,2,1); imshow(uint8(img));   title('Original');
subplot(2,2,2); imshow(uint8(img1));  title('Con ruido');
subplot(2,2,3); imshow(uint8(img2)); title('Filtro m�ximo');
subplot(2,2,4); imshow(uint8(img3)); title('Filtro m�nimo');

% Guardar las im�genes en archivos BMP
imwrite(uint8(img), 'Original.bmp', 'bmp');
imwrite(uint8(img1), 'ConRuido.bmp', 'bmp');
imwrite(uint8(img2), 'FiltroMaximo.bmp', 'bmp');
imwrite(uint8(img3), 'FiltroMinimo.bmp', 'bmp');