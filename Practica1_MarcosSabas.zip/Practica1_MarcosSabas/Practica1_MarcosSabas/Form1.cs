﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1_MarcosSabas
{
    public partial class Form1 : Form
    {
        int A = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Centro(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = "C:\\Users\\Mrcss\\OneDrive\\Documentos\\Visual Studio 2015\\Projects\\Practica1_MarcosSabas\\IMAGENES\\messi.jpg";
            label1.Visible = false;
        }

        private void Fuera(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = " C:\\Users\\Mrcss\\OneDrive\\Documentos\\Visual Studio 2015\\Projects\\Practica1_MarcosSabas\\IMAGENES\\guns.jpg";
            label1.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("evento click");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                pictureBox1.ImageLocation = " C:\\Users\\Mrcss\\OneDrive\\Documentos\\Visual Studio 2015\\Projects\\Practica1_MarcosSabas\\IMAGENES\\spiderman.jpg";
            }
            if (e.KeyChar.ToString() =="X")
            {
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                textBox1.Clear();
                textBox1.Focus();
            }
            else if(e.KeyChar.ToString()=="Y")
            {
                button2.Enabled = true;
                button3.Enabled = false;
                button4.Enabled = false;
                textBox1.Clear();
                textBox1.Focus();
            }
            else if (e.KeyChar.ToString() == "Z")
            {
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = false;
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.Escape)
            {
                MessageBox.Show("pulsaste ESC");
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.E)
            {
                A++;
                label1.Text = "CONTADOR " + A.ToString();
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
