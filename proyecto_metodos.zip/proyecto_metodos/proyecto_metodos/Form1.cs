﻿using System;
using System.Windows.Forms;
using NCalc;

namespace proyecto_metodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //   Materia: Métodos Numericos
        //   Fecha 30/Septiembre/2024
        //   Sabas Perez Marcos Adahir
        //   Castillo García Jonathan Giovany
        //   Estefany Michelle Arana López

        // Método para evaluar la función ingresada en un punto específico
        private double EvaluateFunction(string function, double x)
        {
            Expression e = new Expression(function);
            e.Parameters["x"] = x;
            return Convert.ToDouble(e.Evaluate());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Leer los datos de los TextBox
            string function = textBox1.Text;
            double xl = Convert.ToDouble(textBox2.Text);
            double xu = Convert.ToDouble(textBox3.Text);

            try
            {
                // Primera iteración
                // Calcular el valor de XR como el punto medio de XL y XU
                double xr = (xl + xu) / 2.0;

                // Mostrar el valor de XR en label3
                label3.Text = $"XR = {xr}";

                // Evaluar la función en XR y mostrar el resultado en label4
                double fxr = EvaluateFunction(function, xr);
                label4.Text = $"f(XR) = {fxr}";

                // Evaluar la función en XL y mostrar el resultado en label5
                double fxl = EvaluateFunction(function, xl);
                label5.Text = $"f(XL) = {fxl}";

                // Comprobación: multiplicar f(XR) * f(XL) y mostrar el resultado en label6
                double check = fxr * fxl;
                label6.Text = $"Comprobación= {check}";

                // Regla para cambiar XU o XL
                if (check < 0)
                {
                    xu = xr; // Si f(XR) * f(XL) < 0 entonces XU = XR
                }
                else if (check > 0)
                {
                    xl = xr; // Si f(XR) * f(XL) > 0 entonces XL = XR
                }

                // Segunda iteración
                // Calcular el nuevo valor de XR
                double newXr = (xl + xu) / 2.0;

                // Mostrar el nuevo valor de XR en label7
                label7.Text = $"Nueva XR = {newXr}";

                // Evaluar la función en el nuevo XR y mostrar el resultado en label8
                double newFxr = EvaluateFunction(function, newXr);
                label8.Text = $"f(Nueva XR) = {newFxr}";

                // Evaluar la función en el nuevo XL y mostrar el resultado en label9
                double newFxl = EvaluateFunction(function, xl);
                label9.Text = $"f(Nuevo XL) = {newFxl}";

                // Multiplicación de f(Nueva XR) * f(Nuevo XL) y mostrar en label10
                double newCheck = newFxr * newFxl;
                label10.Text = $"Comprobación = {newCheck}";

                // Calcular la diferencia relativa y mostrar en label11
                double relativeError = Math.Abs((newXr - xr) / newXr) * 100;
                label11.Text = $"Error relativo = {relativeError}%";

                // Tercera iteración
                // Actualizar nuevamente XU o XL basado en la segunda comprobación
                if (newCheck < 0)
                {
                    xu = newXr; // Si f(Nueva XR) * f(Nuevo XL) < 0 entonces XU = Nueva XR
                }
                else if (newCheck > 0)
                {
                    xl = newXr; // Si f(Nueva XR) * f(Nuevo XL) > 0 entonces XL = Nueva XR
                }

                // Calcular el tercer valor de XR
                double thirdXr = (xl + xu) / 2.0;

                // Mostrar el tercer valor de XR en label13
                label13.Text = $"Tercer XR = {thirdXr}";

                // Evaluar la función en el tercer XR y mostrar el resultado en label14
                double thirdFxr = EvaluateFunction(function, thirdXr);
                label14.Text = $"f(Tercer XR) = {thirdFxr}";

                // Evaluar la función en el nuevo XL y mostrar el resultado en label15
                double thirdFxl = EvaluateFunction(function, xl);
                label15.Text = $"f(Nuevo XL) = {thirdFxl}";

                // Multiplicación de f(Tercer XR) * f(Nuevo XL) y mostrar en label16
                double thirdCheck = thirdFxr * thirdFxl;
                label16.Text = $"Comprobación = {thirdCheck}";

                // Calcular la diferencia relativa entre la tercera y segunda multiplicación y mostrar en label17
                double thirdRelativeError = Math.Abs((thirdXr - newXr) / thirdXr) * 100;
                label17.Text = $"Error relativo = {thirdRelativeError}%";

                // Cuarta iteración
                // Actualizar nuevamente XU o XL basado en la segunda comprobación
                if (thirdCheck < 0)
                {
                    xu = thirdXr; // Si f(Nueva XR) * f(Nuevo XL) < 0 entonces XU = Nueva XR
                }
                else if (thirdCheck > 0)
                {
                    xl = thirdXr; // Si f(Nueva XR) * f(Nuevo XL) > 0 entonces XL = Nueva XR
                }

                // Calcular el tercer valor de XR
                double fourXr = (xl + xu) / 2.0;

                // Mostrar el tercer valor de XR en label13
                label18.Text = $"Cuaerta XR = {fourXr}";

                // Evaluar la función en el tercer XR y mostrar el resultado en label14
                double fourFxr = EvaluateFunction(function, fourXr);
                label19.Text = $"f(Cuarto XR) = {fourFxr}";

                // Evaluar la función en el nuevo XL y mostrar el resultado en label15
                double fourFxl = EvaluateFunction(function, xl);
                label20.Text = $"f(Nuevo XL) = {fourFxl}";

                // Multiplicación de f(Tercer XR) * f(Nuevo XL) y mostrar en label16
                double fourCheck = fourFxr * fourFxl;
                label21.Text = $"Comprobación = {fourCheck}";

                // Calcular la diferencia relativa entre la tercera y segunda multiplicación y mostrar en label17
                double fourRelativeError = Math.Abs((fourXr - thirdXr) / fourXr) * 100;
                label22.Text = $"Error relativo = {fourRelativeError}%";
            }
            catch (Exception ex)
            {
                // Mostrar un mensaje en caso de error
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Leer los datos de los TextBox
            string function = textBox1.Text;
            double xl = Convert.ToDouble(textBox2.Text);
            double xu = Convert.ToDouble(textBox3.Text);
            double domainStart = Convert.ToDouble(textBox4.Text); // Valor inicial del dominio
            double domainEnd = Convert.ToDouble(textBox5.Text);   // Valor final del dominio
            double interval = Convert.ToDouble(textBox6.Text);    // Intervalo entre puntos

            try
            {
                // Limpiar el TableLayoutPanel antes de añadir nuevas filas
                tableLayoutPanel1.Controls.Clear();
                tableLayoutPanel1.RowCount = 1;
                tableLayoutPanel1.RowStyles.Clear();
                tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.AutoSize));

                // Agregar encabezados de la tabla
                tableLayoutPanel1.Controls.Add(new Label() { Text = "X" }, 0, 0);
                tableLayoutPanel1.Controls.Add(new Label() { Text = "f(X)" }, 1, 0);

                // Iterar sobre el dominio
                int row = 1;
                for (double x = domainStart; x <= domainEnd; x += interval)
                {
                    // Evaluar la función para el valor actual de X
                    double fx = EvaluateFunction(function, x);

                    // Añadir los valores a la tabla
                    tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                    tableLayoutPanel1.Controls.Add(new Label() { Text = x.ToString() }, 0, row);
                    tableLayoutPanel1.Controls.Add(new Label() { Text = fx.ToString() }, 1, row);

                    row++;
                }
            }
            catch (Exception ex)
            {
                // Mostrar un mensaje en caso de error
                MessageBox.Show($"Error: {ex.Message}");
            }

        }
    }
}
